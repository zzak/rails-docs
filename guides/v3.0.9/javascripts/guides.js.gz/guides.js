function guideMenu(){
  if (document.getElementById('guides').style.display == "none") {
    document.getElementById('guides').style.display = "block";
  } else {
    document.getElementById('guides').style.display = "none";
  }
}
